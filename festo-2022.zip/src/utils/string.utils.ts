export function reverseString(str: string) {
	return str.split('').reverse().join('');
}
